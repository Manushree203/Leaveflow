const mongoose = require("mongoose");

const leaveSchema = new mongoose.Schema({
    name: String,
    email: String,
    type: String,
    fromDate: Date,
    toDate: Date,
    reason: String,
    status: { type: String, default: "Pending" }
});

module.exports = mongoose.model("Leave", leaveSchema);