const express = require("express");
const router = express.Router();
const Leave = require("../models/Leave");

// Apply Leave
router.post("/apply", async (req, res) => {
    try {
        const leave = new Leave(req.body);
        await leave.save();
        res.json({ message: "Leave Applied" });
    } catch (err) {
        res.status(500).json(err);
    }
});

// Get All Requests
router.get("/requests", async (req, res) => {
    try {
        const data = await Leave.find().sort({ _id: -1 }); // newest first
        res.json(data);
    } catch (err) {
        res.status(500).json({ message: "Error fetching requests" });
    }
});

// Get Only Pending Requests
router.get("/pending", async (req, res) => {
    try {
        const data = await Leave.find({ status: "Pending" }).sort({ _id: -1 });
        res.json(data);
    } catch (err) {
        res.status(500).json({ message: "Error fetching pending" });
    }
});

// Update Status
router.put("/update/:id", async (req, res) => {
    try {
        await Leave.findByIdAndUpdate(req.params.id, {
            status: req.body.status
        });
        res.json({ message: "Updated" });
    } catch (err) {
        res.status(500).json({ message: "Error updating status" });
    }
});

module.exports = router;