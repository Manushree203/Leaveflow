const express = require("express");
const cors = require("cors");
const session = require("express-session");
const path = require("path");
const connectDB = require("./db"); // ✅ Import DB connection

const app = express();

// ✅ Connect to MongoDB
connectDB();

// Middleware
app.use(cors({
  origin: "http://localhost:5000",
  credentials: true // needed for sessions to work across frontend/backend
}));
app.use(express.json());

app.use(session({
  secret: "leaveflow-secret",
  resave: false,
  saveUninitialized: true
}));

// Routes
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/leave", require("./routes/leaveRoutes"));

// ✅ Serve frontend — express.static automatically serves index.html for "/"
app.use(express.static(path.join(__dirname, "..")));

// Start server
app.listen(5000, () => {
  console.log("🚀 Server running at http://localhost:5000");
});