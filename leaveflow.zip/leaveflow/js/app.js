﻿// ============================================================
//  LeaveFlow — app.js
//  Single clean file. Works with real Express/MongoDB backend.
// ============================================================

const API = "http://localhost:5000";

// ── Helpers ──────────────────────────────────────────────────

async function getSession() {
  try {
    const res = await fetch(`${API}/api/auth/me`, { credentials: "include" });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

function requireLogin(redirectTo = "index.html") {
  return getSession().then(user => {
    if (!user) window.location.href = redirectTo;
    return user;
  });
}

function formatDate(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric"
  });
}

function statusBadge(status) {
  const s = (status || "pending").toLowerCase();
  const colors = { approved: "#22c55e", rejected: "#ef4444", pending: "#f59e0b" };
  return `<span style="color:${colors[s] || "#888"};font-weight:600;text-transform:capitalize">${s}</span>`;
}

// ── Page: Dashboard (dashboard.html) ─────────────────────────

async function initDashboard() {
  const nameEl = document.getElementById("employeeName");
  if (!nameEl) return;

  const user = await requireLogin();
  nameEl.textContent = user.name;

  // Load this user's leave requests
  const res = await fetch(`${API}/api/leave/requests`, { credentials: "include" });
  const all = await res.json();
  const mine = all.filter(r => r.email === user.email);

  // Pending count
  const pendingEl = document.getElementById("employeePendingCount");
  if (pendingEl) pendingEl.textContent = mine.filter(r => r.status === "Pending").length;

  // Table
  const tbody = document.getElementById("employeeRequestTable");
  if (!tbody) return;

  if (mine.length === 0) {
    tbody.innerHTML = `<tr><td colspan="3" style="text-align:center;color:#888">No requests yet</td></tr>`;
    return;
  }

  tbody.innerHTML = mine.map(r => `
    <tr>
      <td>${r.type}</td>
      <td>${formatDate(r.fromDate)} → ${formatDate(r.toDate)}</td>
      <td>${statusBadge(r.status)}</td>
    </tr>
  `).join("");
}

// ── Page: Apply (apply.html) ──────────────────────────────────

async function initApply() {
  const form = document.getElementById("leaveForm");
  if (!form) return;

  const user = await requireLogin();

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = new FormData(form);

    const data = {
      name: user.name,
      email: user.email,
      type: fd.get("type"),
      fromDate: fd.get("from"),
      toDate: fd.get("to"),
      reason: fd.get("reason")
    };

    const res = await fetch(`${API}/api/leave/apply`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
      credentials: "include"
    });

    if (res.ok) {
      alert("Leave applied ✅");
      window.location.href = "dashboard.html";
    } else {
      alert("Something went wrong ❌");
    }
  });
}

// ── Page: My Requests (requests.html) ────────────────────────

async function initRequests() {
  const tbody = document.getElementById("requestTable");
  if (!tbody) return;

  const user = await requireLogin();

  const res = await fetch(`${API}/api/leave/requests`, { credentials: "include" });
  const all = await res.json();
  const mine = all.filter(r => r.email === user.email);

  if (mine.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:#888;padding:20px">No requests yet. <a href="apply.html">Apply for leave</a></td></tr>`;
    return;
  }

  tbody.innerHTML = mine.map(r => {
    const days = Math.ceil((new Date(r.toDate) - new Date(r.fromDate)) / (1000*60*60*24)) + 1;
    const reason = (r.reason || "-").replace(/'/g, "\'");
    return `
      <tr>
        <td>${r.type}</td>
        <td>${formatDate(r.fromDate)} → ${formatDate(r.toDate)}</td>
        <td>${days} day${days !== 1 ? "s" : ""}</td>
        <td>${statusBadge(r.status)}</td>
        <td><button class="button-secondary btn-sm" onclick="alert('Type: ${r.type}\nReason: ${reason}\nStatus: ${r.status}')">View</button></td>
      </tr>
    `;
  }).join("");
}

// ── Page: Admin (admin.html) ──────────────────────────────────

async function initAdmin() {
  const nameEl = document.getElementById("adminName");
  if (!nameEl) return;

  const user = await requireLogin();
  if (user.role !== "admin") {
    alert("Admin access only");
    window.location.href = "index.html";
    return;
  }
  nameEl.textContent = user.name;

  await loadAdminDashboard();
}

async function loadAdminDashboard() {
  const res = await fetch(`${API}/api/leave/requests`, { credentials: "include" });
  const requests = await res.json();

  // — Counts —
  const pending  = requests.filter(r => r.status === "Pending").length;
  const approved = requests.filter(r => r.status === "Approved").length;
  const rejected = requests.filter(r => r.status === "Rejected").length;

  const queueEl = document.getElementById("approvalQueueCount");
  if (queueEl) queueEl.textContent = `${pending} requests`;

  const metricsEl = document.getElementById("adminMetrics");
  if (metricsEl) {
    metricsEl.innerHTML = `
      <div class="metric-card"><h3>${requests.length}</h3><p>Total Requests</p></div>
      <div class="metric-card"><h3>${pending}</h3><p>Pending</p></div>
      <div class="metric-card"><h3>${approved}</h3><p>Approved</p></div>
      <div class="metric-card"><h3>${rejected}</h3><p>Rejected</p></div>
    `;
  }

  // — Table —
  const tbody = document.getElementById("adminRequestTable");
  if (!tbody) return;

  if (requests.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#888;padding:20px">No leave requests yet</td></tr>`;
    return;
  }

  tbody.innerHTML = requests.map(r => `
    <tr>
      <td>${r.name}</td>
      <td>${r.type}</td>
      <td>${formatDate(r.fromDate)} → ${formatDate(r.toDate)}</td>
      <td>${statusBadge(r.status)}</td>
      <td>Standard Policy</td>
      <td>
        ${r.status === "Pending"
          ? `<button onclick="updateStatus('${r._id}','Approved')" class="button-primary" style="margin-right:6px">Approve</button>
             <button onclick="updateStatus('${r._id}','Rejected')" class="button-secondary">Reject</button>`
          : "✔ Done"
        }
      </td>
    </tr>
  `).join("");
}

window.updateStatus = async function(id, status) {
  await fetch(`${API}/api/leave/update/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status }),
    credentials: "include"
  });
  loadAdminDashboard(); // refresh table only
};

// ── Auto-init based on page ───────────────────────────────────

document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;
  if (page === "employee")  initDashboard();
  if (page === "apply")     initApply();
  if (page === "requests")  initRequests();
  if (page === "admin")     initAdmin();
});