﻿const STORAGE_KEY = "leaveflow-demo-state";

const defaultState = {
  employee: {
    profile: {
      name: "Employee",
      role: "Employee",
      team: "General"
    },
    balances: [
      { label: "Annual Leave", used: 8, total: 18, accent: "cyan", description: "Available for planned vacations and breaks." },
      { label: "Sick Leave", used: 2, total: 10, accent: "amber", description: "Reserved for health-related absences." },
      { label: "Personal Leave", used: 1, total: 6, accent: "olive", description: "For errands, family events, and personal needs." },
      { label: "Work From Anywhere", used: 3, total: 12, accent: "cyan", description: "Distributed working days outside your primary office." }
    ]
  },
  admin: {
    profile: {
      name: "Admin",
      role: "Administrator",
      team: "Operations"
    }
  },
  teamCoverage: [
    { department: "Design", onLeave: 2, capacity: 10 },
    { department: "Engineering", onLeave: 5, capacity: 28 },
    { department: "People Ops", onLeave: 1, capacity: 6 },
    { department: "Customer Success", onLeave: 3, capacity: 14 }
  ],
  requests: [
    {
      id: 101,
      employee: "Employee",
      department: "General",
      type: "Annual Leave",
      startDate: "2026-04-18",
      endDate: "2026-04-22",
      days: 5,
      status: "approved",
      reason: "Family wedding and travel",
      balanceKey: "Annual Leave"
    },
    {
      id: 102,
      employee: "Employee",
      department: "General",
      type: "Sick Leave",
      startDate: "2026-04-08",
      endDate: "2026-04-09",
      days: 2,
      status: "approved",
      reason: "Medical recovery",
      balanceKey: "Sick Leave"
    },
    {
      id: 103,
      employee: "Employee",
      department: "General",
      type: "Work From Anywhere",
      startDate: "2026-04-29",
      endDate: "2026-05-01",
      days: 3,
      status: "pending",
      reason: "Working remotely while visiting family",
      balanceKey: "Work From Anywhere"
    },    
    {
      id: 105,
      employee: "Elena Park",
      department: "Customer Success",
      type: "Personal Leave",
      startDate: "2026-04-16",
      endDate: "2026-04-16",
      days: 1,
      status: "pending",
      reason: "Family appointment",
      balanceKey: "Personal Leave"
    },
    {
      id: 106,
      employee: "Rahul Menon",
      department: "Engineering",
      type: "Annual Leave",
      startDate: "2026-04-21",
      endDate: "2026-04-23",
      days: 3,
      status: "pending",
      reason: "Festival travel",
      balanceKey: "Annual Leave"
    },
    {
      id: 107,
      employee: "Ava Collins",
      department: "People Ops",
      type: "Personal Leave",
      startDate: "2026-04-27",
      endDate: "2026-04-28",
      days: 2,
      status: "rejected",
      reason: "Personal commitments during payroll close",
      balanceKey: "Personal Leave"
    }
  ],
  peakPeriods: [
    { start: "2026-04-20", end: "2026-04-24", label: "Quarter-close staffing window" },
    { start: "2026-04-28", end: "2026-04-30", label: "Product launch support period" }
  ]
};

function cloneDefaultState() {
  return JSON.parse(JSON.stringify(defaultState));
}

function readState() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      const fresh = cloneDefaultState();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
      return fresh;
    }

    const parsed = JSON.parse(stored);
    const baseState = cloneDefaultState();
    const mergedState = {
      ...baseState,
      ...parsed,
      employee: {
        ...baseState.employee,
        ...(parsed.employee || {}),
        profile: {
          ...baseState.employee.profile,
          ...((parsed.employee && parsed.employee.profile) || {})
        }
      },
      admin: {
        ...baseState.admin,
        ...(parsed.admin || {}),
        profile: {
          ...baseState.admin.profile,
          ...((parsed.admin && parsed.admin.profile) || {})
        }
      }
    };
    if (mergedState.employee.profile.name === "John Doe") {
      mergedState.employee.profile.name = "Employee";
      mergedState.employee.profile.role = "Employee";
      mergedState.employee.profile.team = mergedState.employee.profile.team || "General";
    }
    if (!mergedState.admin.profile.name || mergedState.admin.profile.name === "Sarah Parker") {
      mergedState.admin.profile.name = "Admin";
    }
    mergedState.requests = mergedState.requests.map((request) => {
      if (request.employee === "John Doe") {
        return {
          ...request,
          employee: mergedState.employee.profile.name,
          department: mergedState.employee.profile.team || request.department
        };
      }
      return request;
    });
    return mergedState;
  } catch (error) {
    const fresh = cloneDefaultState();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    return fresh;
  }
}

function writeState(nextState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(nextState));
}

function resetDemoState() {
  const fresh = cloneDefaultState();
  writeState(fresh);
  return fresh;
}

function saveProfile(role, profile) {
  const state = readState();

  if (role === "admin") {
    state.admin.profile = {
      ...state.admin.profile,
      ...profile
    };
  } else {
    const previousName = state.employee.profile.name;
    state.employee.profile = {
      ...state.employee.profile,
      ...profile
    };

    if (profile.name && previousName && previousName !== profile.name) {
      state.requests = state.requests.map((request) => {
        if (request.employee === previousName) {
          return {
            ...request,
            employee: profile.name,
            department: profile.team || request.department
          };
        }
        return request;
      });
    }
  }

  writeState(state);
  return state;
}

window.leaveflowStore = {
  readState,
  writeState,
  resetDemoState,
  saveProfile,
  defaultState: cloneDefaultState()
};

