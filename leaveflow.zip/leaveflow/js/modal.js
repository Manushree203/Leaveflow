﻿(function initializeModal() {
  const modal = document.getElementById("requestModal");
  if (!modal) return;

  const openButtons = document.querySelectorAll("[data-open-request]");
  const closeButtons = document.querySelectorAll("[data-close-request]");

  function openModal() {
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  }

  function closeModal() {
    modal.classList.remove("open");
    modal.setAttribute("aria-hidden", "true");
  }

  openButtons.forEach(btn => btn.addEventListener("click", openModal));
  closeButtons.forEach(btn => btn.addEventListener("click", closeModal));

  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  // optional global access
  window.openRequestModal = openModal;
  window.closeRequestModal = closeModal;
})();