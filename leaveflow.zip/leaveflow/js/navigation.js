﻿// navigation.js

document.addEventListener("DOMContentLoaded", () => {
  const navLinks = document.querySelectorAll(".nav-item");

  navLinks.forEach(link => {
    link.addEventListener("click", function (e) {
      e.preventDefault();

      // Get target section ID
      const targetId = this.getAttribute("href").substring(1);
      const target = document.getElementById(targetId);

      if (target) {
        target.scrollIntoView({ behavior: "smooth" });
      }

      // Active state
      navLinks.forEach(l => l.classList.remove("active"));
      this.classList.add("active");
    });
  });

  // Button scroll (footer button)
  const scrollBtn = document.querySelector("[data-scroll-target]");
  if (scrollBtn) {
    scrollBtn.addEventListener("click", () => {
      const targetId = scrollBtn.getAttribute("data-scroll-target");
      const target = document.getElementById(targetId);

      if (target) {
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  }
});