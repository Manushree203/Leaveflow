﻿(function initializeLanding() {
  const roleButtons = document.querySelectorAll("[data-role-target]");
  const rolePanels = document.querySelectorAll("[data-role-panel]");
  const authToggleButtons = document.querySelectorAll("[data-auth-mode]");
  const authForms = document.querySelectorAll("[data-auth-form]");
  const directButtons = document.querySelectorAll("[data-direct]");

  if (!roleButtons.length) return;

  // ✅ FIX 1: ROLE SWITCH (WORKING PROPERLY)
  function setRole(role) {
    roleButtons.forEach((button) => {
      button.classList.toggle("active", button.dataset.roleTarget === role);
    });

    rolePanels.forEach((panel) => {
      panel.classList.toggle("active", panel.dataset.rolePanel === role);
    });

    // ✅ Reset auth mode to login when switching role
    setAuthMode(role, "login");
  }

  // ✅ FIX 2: AUTH TOGGLE (LOGIN / REGISTER)
  function setAuthMode(role, mode) {

    authToggleButtons.forEach((button) => {
      const isSameRole = button.dataset.role === role;
      const isMatch = isSameRole && button.dataset.authMode === mode;

      // Only affect buttons of selected role
      if (isSameRole) {
        button.classList.toggle("active", isMatch);
      }
    });

    authForms.forEach((form) => {
      const isMatch = form.dataset.authForm === `${role}-${mode}`;
      form.classList.toggle("active", isMatch);
    });
  }

  // ✅ ROUTING
  function routeTo(role) {
    window.location.href = role === "admin" ? "admin.html" : "dashboard.html";
  }

  // ✅ SAVE USER
  function saveSubmittedProfile(role, form) {
    const formData = new FormData(form);
    const name = (formData.get("name") || "").toString().trim();
    const team = (formData.get("team") || "").toString().trim();

    if (!name) return;

    localStorage.setItem("leaveflowUser", JSON.stringify({
      name,
      team,
      role
    }));
  }

  // ✅ EVENTS
  roleButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setRole(button.dataset.roleTarget);
    });
  });

  authToggleButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setAuthMode(button.dataset.role, button.dataset.authMode);
    });
  });

 authForms.forEach((form) => {
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const [role, mode] = form.dataset.authForm.split("-");
    const formData = new FormData(form);

    const data = {
      name: formData.get("name"),
      email: formData.get("email"),
      password: formData.get("password"),
      role
    };

    try {
      const url =
        mode === "login"
          ? "http://localhost:5000/api/auth/login"
          : "http://localhost:5000/api/auth/register";

      const res = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
      });

      const result = await res.json();
      console.log(result);

      // redirect after login
      window.location.href =
        role === "admin" ? "admin.html" : "dashboard.html";

    } catch (err) {
      console.error("Auth error:", err);
    }
  });
});

  directButtons.forEach((button) => {
    button.addEventListener("click", () => {
      routeTo(button.dataset.direct);
    });
  });
  (function initializeApp() {

  // ================= LANDING PAGE =================
  const roleButtons = document.querySelectorAll("[data-role-target]");
  const rolePanels = document.querySelectorAll("[data-role-panel]");
  const authToggleButtons = document.querySelectorAll("[data-auth-mode]");
  const authForms = document.querySelectorAll("[data-auth-form]");
  const directButtons = document.querySelectorAll("[data-direct]");

  // Only run landing logic if elements exist
  if (roleButtons.length) {

    function setRole(role) {
      roleButtons.forEach((button) => {
        button.classList.toggle("active", button.dataset.roleTarget === role);
      });

      rolePanels.forEach((panel) => {
        panel.classList.toggle("active", panel.dataset.rolePanel === role);
      });

      setAuthMode(role, "login");
    }

    function setAuthMode(role, mode) {
      authToggleButtons.forEach((button) => {
        const isSameRole = button.dataset.role === role;
        const isMatch = isSameRole && button.dataset.authMode === mode;

        if (isSameRole) {
          button.classList.toggle("active", isMatch);
        }
      });

      authForms.forEach((form) => {
        const isMatch = form.dataset.authForm === `${role}-${mode}`;
        form.classList.toggle("active", isMatch);
      });
    }

    function routeTo(role) {
      window.location.href = role === "admin" ? "admin.html" : "dashboard.html";
    }

    function saveSubmittedProfile(role, form) {
      const formData = new FormData(form);

      const name = (formData.get("name") || "").trim();
      const team = (formData.get("team") || "").trim();

      if (!name) return;

      localStorage.setItem("leaveflowUser", JSON.stringify({
        name,
        team,
        role
      }));
    }

    roleButtons.forEach((button) => {
      button.addEventListener("click", () => {
        setRole(button.dataset.roleTarget);
      });
    });

    authToggleButtons.forEach((button) => {
      button.addEventListener("click", () => {
        setAuthMode(button.dataset.role, button.dataset.authMode);
      });
    });

    authForms.forEach((form) => {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const [role] = form.dataset.authForm.split("-");
        saveSubmittedProfile(role, form);
        routeTo(role);
      });
    });

    directButtons.forEach((button) => {
      button.addEventListener("click", () => {
        routeTo(button.dataset.direct);
      });
    });

    setRole("employee");
  }

  // ================= DASHBOARD (EMPLOYEE) =================

  const user = JSON.parse(localStorage.getItem("leaveflowUser"));

  if (user) {
    const empName = document.getElementById("employeeName");
    const adminName = document.getElementById("adminName");

    if (empName) empName.innerText = user.name;
    if (adminName) adminName.innerText = user.name;
  }

  // ================= APPLY LEAVE =================

  const form = document.getElementById("leaveForm");

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();

      const formData = new FormData(this);

      const newLeave = {
        type: formData.get("type"),
        from: formData.get("from"),
        to: formData.get("to"),
        reason: formData.get("reason"),
        status: "Pending"
      };

      const form = document.getElementById("leaveForm");

if (form) {
  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    const leaveData = {
      type: formData.get("type"),
      from: formData.get("from"),
      to: formData.get("to"),
      reason: formData.get("reason")
    };

    try {
      const res = await fetch("http://localhost:5000/api/leave/apply", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(leaveData)
      });

      const result = await res.json();
      console.log(result);

      alert("Leave Applied ✅");
      loadLeaves();

    } catch (err) {
      console.error(err);
    }
  });
}
      closeModal();
      loadLeaves();
    });
  }

  // ================= LOAD LEAVES =================

  window.loadLeaves = function () {
    const table = document.getElementById("employeeRequestTable");
    if (!table) return;

    table.innerHTML = "";

window.loadLeaves = async function () {
  const table = document.getElementById("employeeRequestTable");
  if (!table) return;

  table.innerHTML = "";

  try {
    const res = await fetch("http://localhost:5000/api/leave");
    const leaves = await res.json();

    leaves.forEach((leave) => {
      table.innerHTML += `
        <tr>
          <td>${leave.type}</td>
          <td>${leave.from} → ${leave.to}</td>
          <td>${leave.status}</td>
        </tr>
      `;
    });

  } catch (err) {
    console.error(err);
  }
};
    leaves.forEach((leave) => {
      const row = `
        <tr>
          <td>${leave.type}</td>
          <td>${leave.from} → ${leave.to}</td>
          <td>${leave.status}</td>
        </tr>
      `;
      table.innerHTML += row;
    });
  };

})();

  // ✅ INITIAL STATE
  setRole("employee");

})();